﻿using System;
using Accounts;

namespace BankAccounts
{
    public class BankAccount : Account, IBankAccount
    {
        private string owner;
        private AccountType type;
        private Guid uniqueId;
        public override string Owner
        {
            get
            {
                return owner;
            }
            set
            {
                owner = value;
            }
        }
        public override AccountType Type { get { return type; } set { type = value; } }
        public override Guid UniqueId { get { return uniqueId; } set { uniqueId = value; } }
        public string Currency { get; set; }
        public double Amount { get; set; }

        public void Deposit( double amount)
        {
            Amount = Amount + amount;
        }

        public void Transfer(double amount, BankAccount account)
        {
            account.Amount = account.Amount + amount;
            Amount = Amount - amount;
        }

        public void WithDraw(double amount)
        {
            Amount = Amount - amount;
        }
    }
}
