﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistence.Migrations
{
    public partial class initialcommit : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Desgination = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    JoiningDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Street = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PinCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ImagePath = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Guid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreateDate", "Desgination", "Guid", "ImagePath", "JoiningDate", "Name", "PinCode", "State", "Street" },
                values: new object[] { 1, "test1", "", "India", new DateTime(2022, 7, 1, 11, 51, 51, 215, DateTimeKind.Local).AddTicks(2079), "Test Engineer", new Guid("db6d1a1a-ab48-4282-b55c-57c6b4477314"), "", new DateTime(2012, 4, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "John", "", "", "" });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreateDate", "Desgination", "Guid", "ImagePath", "JoiningDate", "Name", "PinCode", "State", "Street" },
                values: new object[] { 2, "test1", "", "India", new DateTime(2022, 7, 1, 11, 51, 51, 216, DateTimeKind.Local).AddTicks(548), "PMO", new Guid("b0c93abc-643c-4316-9eec-0fd22bfb98a4"), "", new DateTime(2019, 9, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), "Luther", "", "", "" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
