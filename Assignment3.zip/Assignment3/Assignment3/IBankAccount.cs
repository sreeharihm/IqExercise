﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccounts
{
    public interface IBankAccount
    {
        void Deposit( double amount);
        void WithDraw(double amount);

        void Transfer(double amount, BankAccount account);
    }
}
