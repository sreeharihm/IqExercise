﻿using System;
using Users;
using BankAccounts;
using System.Collections.Generic;
using System.Linq;
using GoodsAccounts;
using ShareAccounts;

namespace Assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<User> userList = new List<User>();
            Console.WriteLine("Assignment 3");
            IntialiseTom(userList);
            IntialiseJerry(userList);
            IntialiseDuck(userList);
            string ch;
            int accountType;
            Console.WriteLine("Enter UserName:");
            string username = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter Password:");
            string password = Convert.ToString(Console.ReadLine());
            var user = userList.FirstOrDefault(x => x.UserName.Equals(username) && x.Password.Equals(password));
            if (user == null)
            {
                Console.WriteLine("Invalid user details");
                return;
            }
            user.Open();
            ListUserAccounts(user);
            BankOperations(user);
            ShareOperations(user);
            GoodsOperations(user);
            AccountStatement(user);
            user.Close();
            Console.ReadKey();
        }
        public static void AccountStatement(User user) {
            Console.WriteLine("Account Statement");
            int i = 1;
            foreach (var l in user.Logs)
            {
                Console.WriteLine(i+": "+l);
                i++;
            }
        }
        public static void GoodsOperations(User user)
        {
            Console.WriteLine("Goods Operation");
            Console.WriteLine("1. Buy\n2. Sell");
            var action = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the account");
            Guid account = Guid.Parse(Console.ReadLine());
            if (action == 1)
            {
                var accountDetails = user.GoodsAccounts.Where(x => x.UniqueId.Equals(account)).FirstOrDefault();
                accountDetails.Buy(amt);
                user.Logs.Add("Goods Buy:" + accountDetails.UniqueId + ":" + Convert.ToString(amt));

            }
            else
            {
                var accountDetails = user.GoodsAccounts.Where(x => x.UniqueId.Equals(account)).FirstOrDefault();
                accountDetails.Sell(amt);
                user.Logs.Add("Goods Sell:" + accountDetails.UniqueId + ":" + Convert.ToString(amt));
            }
        }
        public static void ShareOperations(User user)
        {
            Console.WriteLine("Share Operation");
            Console.WriteLine("1. Buy\n2. Sell");
            var action = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the account");
            Guid account = Guid.Parse(Console.ReadLine());
            Console.WriteLine("Enter the percentage");
            int per = Convert.ToInt32(Console.ReadLine());
            if (action == 1)
            {
                var accountDetails = user.ShareAccounts.Where(x => x.UniqueId.Equals(account)).FirstOrDefault();
                accountDetails.Buy(amt, per);
                user.Logs.Add("Share Buy:" + accountDetails.UniqueId + ":" + Convert.ToString(amt));

            }
            else
            {
                var accountDetails = user.ShareAccounts.Where(x => x.UniqueId.Equals(account)).FirstOrDefault();
                accountDetails.Sell(amt, per);
                user.Logs.Add("Share Sell:"+accountDetails.UniqueId+":" + Convert.ToString(amt));
            }
        }
        public static void BankOperations(User user)
        {
            Console.WriteLine("Bank Operation");
            Console.WriteLine("1. Deposit\n2. Withdraw");
            var action = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the account");
            Guid account = Guid.Parse(Console.ReadLine());
            if (action == 1)
            {
                var accountDetails = user.BankAccounts.Where(x => x.UniqueId.Equals(account)).FirstOrDefault();
                accountDetails.Deposit(amt);
                user.Logs.Add("Money Deposit:" + accountDetails.UniqueId + ":" +Convert.ToString(amt));

            }
            else
            {
                var accountDetails = user.BankAccounts.Where(x => x.UniqueId.Equals(account)).FirstOrDefault();
                accountDetails.WithDraw(amt);
                user.Logs.Add("Money Withdraw:" + accountDetails.UniqueId + ":" + Convert.ToString(amt));
            }
        }
        public static void ListUserAccounts(User user)
        {
            Console.WriteLine("List of Accounts");
            int i = 1;
            foreach (var acct in user.BankAccounts)
            {
                Console.WriteLine(i + " Bank- " + acct.UniqueId);
                i++;
            }
            foreach (var acct in user.ShareAccounts)
            {
                Console.WriteLine(i + " Share- " + acct.UniqueId);
                i++;
            }
            foreach (var acct in user.GoodsAccounts)
            {
                Console.WriteLine(i + " Goods- " + acct.UniqueId);
                i++;
            }
        }
        public static void IntialiseTom(List<User> userList)
        {
            User tom = new User();
            tom.UserName = "tom";
            tom.Password = "tom";
            tom.Name = "tom";
            tom.BankAccounts = new List<BankAccount>();
            var bk1 = new BankAccount
            {
                Currency = "$",
                UniqueId = Guid.NewGuid(),
                Amount = 100
            };
            tom.BankAccounts.Add(bk1);
            var bk2 = new BankAccount
            {
                Currency = "$",
                UniqueId = Guid.NewGuid(),
                Amount = 150
            };
            tom.BankAccounts.Add(bk2);
            var bk3 = new BankAccount
            {
                Currency = "$",
                UniqueId = Guid.NewGuid(),
                Amount = 200
            };
            tom.BankAccounts.Add(bk3);
            tom.GoodsAccounts = new List<GoodsAccount>();
            var gd1 = new GoodsAccount
            {
                UniqueId = Guid.NewGuid(),
                Unit = "Kg",
                TypeOfGood = "Normal",
                Amount = 100
            };
            tom.GoodsAccounts.Add(gd1);
            var gd2 = new GoodsAccount
            {
                UniqueId = Guid.NewGuid(),
                Unit = "Kg",
                TypeOfGood = "Normal",
                Amount = 100
            };
            tom.GoodsAccounts.Add(gd2);
            var gd3 = new GoodsAccount
            {
                UniqueId = Guid.NewGuid(),
                Unit = "Kg",
                TypeOfGood = "Normal",
                Amount = 100
            };
            tom.GoodsAccounts.Add(gd3);
            tom.ShareAccounts = new List<ShareAccount>();
            var sh1 = new ShareAccount
            {
                UniqueId = Guid.NewGuid(),
                Percentage = 10,
                Amount = 100
            };
            tom.ShareAccounts.Add(sh1);
            var sh2 = new ShareAccount
            {
                UniqueId = Guid.NewGuid(),
                Percentage = 10,
                Amount = 100
            };
            tom.ShareAccounts.Add(sh2);
            var sh3 = new ShareAccount
            {
                UniqueId = Guid.NewGuid(),
                Percentage = 10,
                Amount = 100
            };
            tom.ShareAccounts.Add(sh3);
            userList.Add(tom);
        }
        public static void IntialiseJerry(List<User> userList)
        {
            User jerry = new User();
            jerry.UserName = "jerry";
            jerry.Password = "jerry";
            jerry.Name = "jerry";
            jerry.BankAccounts = new System.Collections.Generic.List<BankAccount>();
            var bk1 = new BankAccount
            {
                Currency = "$",
                UniqueId = Guid.NewGuid(),
                Amount = 50
            };
            jerry.BankAccounts.Add(bk1);
            var bk2 = new BankAccount
            {
                Currency = "$",
                UniqueId = Guid.NewGuid(),
                Amount = 150
            };
            jerry.BankAccounts.Add(bk2);
            var bk3 = new BankAccount
            {
                Currency = "$",
                UniqueId = Guid.NewGuid(),
                Amount = 20
            };
            jerry.BankAccounts.Add(bk3);
            jerry.GoodsAccounts = new List<GoodsAccount>();
            var gd1 = new GoodsAccount
            {
                UniqueId = Guid.NewGuid(),
                Unit = "Kg",
                TypeOfGood = "Normal",
                Amount = 100
            };
            jerry.GoodsAccounts.Add(gd1);
            var gd2 = new GoodsAccount
            {
                UniqueId = Guid.NewGuid(),
                Unit = "Kg",
                TypeOfGood = "Normal",
                Amount = 100
            };
            jerry.GoodsAccounts.Add(gd2);
            var gd3 = new GoodsAccount
            {
                UniqueId = Guid.NewGuid(),
                Unit = "Kg",
                TypeOfGood = "Normal",
                Amount = 100
            };
            jerry.GoodsAccounts.Add(gd3);
            jerry.ShareAccounts = new List<ShareAccount>();
            var sh1 = new ShareAccount
            {
                UniqueId = Guid.NewGuid(),
                Percentage = 10,
                Amount = 100
            };
            jerry.ShareAccounts.Add(sh1);
            var sh2 = new ShareAccount
            {
                UniqueId = Guid.NewGuid(),
                Percentage = 10,
                Amount = 100
            };
            jerry.ShareAccounts.Add(sh2);
            var sh3 = new ShareAccount
            {
                UniqueId = Guid.NewGuid(),
                Percentage = 10,
                Amount = 100
            };
            jerry.ShareAccounts.Add(sh3);
            userList.Add(jerry);
        }
        public static void IntialiseDuck(List<User> userList)
        {
            User duck = new User();
            duck.UserName = "duck";
            duck.Password = "duck";
            duck.Name = "duck";
            duck.BankAccounts = new System.Collections.Generic.List<BankAccount>();
            var bk1 = new BankAccount
            {
                Currency = "$",
                UniqueId = Guid.NewGuid(),
                Amount = 50
            };
            duck.BankAccounts.Add(bk1);
            var bk2 = new BankAccount
            {
                Currency = "$",
                UniqueId = Guid.NewGuid(),
                Amount = 50
            };
            duck.BankAccounts.Add(bk2);
            var bk3 = new BankAccount
            {
                Currency = "$",
                UniqueId = Guid.NewGuid(),
                Amount = 20
            };
            duck.BankAccounts.Add(bk3);
            duck.GoodsAccounts = new List<GoodsAccount>();
            var gd1 = new GoodsAccount
            {
                UniqueId = Guid.NewGuid(),
                Unit = "Kg",
                TypeOfGood = "Normal",
                Amount = 100
            };
            duck.GoodsAccounts.Add(gd1);
            var gd2 = new GoodsAccount
            {
                UniqueId = Guid.NewGuid(),
                Unit = "Kg",
                TypeOfGood = "Normal",
                Amount = 100
            };
            duck.GoodsAccounts.Add(gd2);
            var gd3 = new GoodsAccount
            {
                UniqueId = Guid.NewGuid(),
                Unit = "Kg",
                TypeOfGood = "Normal",
                Amount = 100
            };
            duck.GoodsAccounts.Add(gd3);
            duck.ShareAccounts = new List<ShareAccount>();
            var sh1 = new ShareAccount
            {
                UniqueId = Guid.NewGuid(),
                Percentage = 10,
                Amount = 100
            };
            duck.ShareAccounts.Add(sh1);
            var sh2 = new ShareAccount
            {
                UniqueId = Guid.NewGuid(),
                Percentage = 10,
                Amount = 100
            };
            duck.ShareAccounts.Add(sh2);
            var sh3 = new ShareAccount
            {
                UniqueId = Guid.NewGuid(),
                Percentage = 10,
                Amount = 100
            };
            duck.ShareAccounts.Add(sh3);
            userList.Add(duck);
        }
    }
}
