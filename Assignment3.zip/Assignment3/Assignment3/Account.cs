﻿using System;

namespace Accounts
{
    public abstract class Account
    {
        public abstract string Owner { get; set; }
        public abstract AccountType Type { get; set; }
        public abstract Guid UniqueId { get; set; }
        
    }

    public enum AccountType { 
        Shared,
        NotShared
    }
}
