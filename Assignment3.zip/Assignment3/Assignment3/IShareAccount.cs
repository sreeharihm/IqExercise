﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShareAccounts
{
    public interface IShareAccount
    {
        public void Buy(double amt, int percentage);
        public void Sell(double amt, int percentage);
        public void Transfer(ShareAccount s);
    }
}
