﻿using BankAccounts;
using GoodsAccounts;
using ShareAccounts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Users
{
    public class User
    {
        public User() {
            Logs = new List<string>();
        }
        public string Name { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public List<BankAccount> BankAccounts { get; set; }
        public List<ShareAccount> ShareAccounts { get; set; }
        public List<GoodsAccount> GoodsAccounts { get; set; }

        public List<string> Logs { get; set; }
        public void Open()
        {
            Console.WriteLine("Connection opened...");
        }
        public void Close()
        {
            Console.WriteLine("Connection closed...");
        }
    }
}
