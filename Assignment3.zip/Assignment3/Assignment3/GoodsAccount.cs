﻿using Accounts;
using System;
using System.Collections.Generic;
using System.Text;

namespace GoodsAccounts 
{
    public class GoodsAccount : Account, IGoodsAccount
    {
        private string owner;
        private AccountType type;
        private Guid uniqueId;
        public override string Owner
        {
            get
            {
                return owner;
            }
            set
            {
                owner = value;
            }
        }
        public override AccountType Type { get { return type; } set { type = value; } }
        public override Guid UniqueId { get { return uniqueId; } set { uniqueId = value; } }

        public string TypeOfGood { get; set; }
        public double Amount { get; set; }
        public string Unit { get; set; }

        public void Buy(double amt)
        {
            Amount = Amount + amt;
        }

        public void Sell(double amt)
        {
            Amount = Amount - amt;
        }
    }
}
