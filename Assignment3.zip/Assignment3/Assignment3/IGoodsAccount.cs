﻿using ShareAccounts;
using System;
using System.Collections.Generic;
using System.Text;

namespace GoodsAccounts
{
    public interface IGoodsAccount
    {
        public void Buy(double amt);
        public void Sell(double amt);
    }
}
