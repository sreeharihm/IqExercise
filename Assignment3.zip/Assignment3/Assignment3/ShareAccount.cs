﻿using Accounts;
using BankAccounts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShareAccounts
{
    public class ShareAccount : Account, IShareAccount
    {
        private string owner;
        private AccountType type;
        private Guid uniqueId;
        public override string Owner
        {
            get
            {
                return owner;
            }
            set
            {
                owner = value;
            }
        }
        public override AccountType Type { get { return type; } set { type = value; } }
        public override Guid UniqueId { get { return uniqueId; } set { uniqueId = value; } }
        public double Amount { get; set; }
        public int Percentage { get; set; }

        public void Buy(double amt, int percentage)
        {
            Amount = Amount + amt;
            Percentage = percentage;
        }

        public void Sell(double amt, int percentage)
        {
            Amount = Amount - amt;
            Percentage = percentage;
        }

        public void Transfer(ShareAccount s)
        {
            throw new NotImplementedException();
        }
    }
}
